export const success = 200;
export const fail = 400;
export const generalSuccessMessages = 250;